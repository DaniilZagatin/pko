"""Отчёты: в раздел «Связи» попадают только ссылки на объекты."""

import unittest

from fixture_support import ensure_fixture
from pko.git.repo import GitRepo
from pko.history.selector import select_versions
from pko.model.schema import REFERENCE_LINKS
from pko.pipeline import analyze_version
from pko.render.comparison import render_comparison
from pko.render.passports import render_passports
from pko.render.taxonomy import render_taxonomy
from pko.diff.engine import diff_models

# Технические привязки: пакет реализации и устойчивая идентичность объекта.
TECHNICAL_LINKS = ("package", "limit_key", "stable_key")


class LinkRenderingTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        repo = GitRepo(ensure_fixture())
        versions = select_versions(repo, "master", max_versions=2)
        cls.model = analyze_version(
            repo=repo, version=versions[-1], repo_name="mini_repo", branch="master"
        ).model
        cls.old = analyze_version(
            repo=repo, version=versions[0], repo_name="mini_repo", branch="master"
        ).model

    def test_technical_keys_are_not_rendered_as_links(self):
        """`limit_key` и `stable_key` — не связи; в отчёте они выглядели ссылками."""
        values = {
            v
            for obj in self.model.objects
            for rel, targets in obj.links.items()
            if rel in TECHNICAL_LINKS
            for v in targets
        }
        self.assertTrue(values, "в модели есть технические привязки")

        for name, html in (
            ("taxonomy", render_taxonomy(self.model)),
            ("passports", render_passports(self.model)),
        ):
            for value in values:
                with self.subTest(report=name, value=value):
                    self.assertNotIn(
                        f'class="tag tag-grd">{value}<', html,
                        msg="технический ключ отрисован как ссылка на объект",
                    )

    def test_object_links_are_still_rendered(self):
        html = render_passports(self.model)
        journey = self.model.by_kind("JOURNEY")[0]
        need_id = journey.links["need"][0]
        self.assertIn(need_id, html)
        self.assertTrue(set(journey.links) & REFERENCE_LINKS)

    def test_reports_render_without_errors(self):
        diff = diff_models(self.old, self.model)
        for html in (
            render_taxonomy(self.model, "обзор"),
            render_passports(self.model),
            render_comparison(diff, "оценка"),
        ):
            self.assertTrue(html.startswith("<!DOCTYPE html>"))
            self.assertIn("</html>", html)


if __name__ == "__main__":
    unittest.main()


class ReadabilityTest(unittest.TestCase):
    """Отчёт должен объяснять, а не предъявлять координаты."""

    def _model(self):
        from pko.model.schema import Evidence, PkoModel, PkoObject

        model = PkoModel(meta={"repo": "demo", "commit": "6a225969b0cc", "version_label": "current"})
        obj = PkoObject(id="BBB-001", kind="BBB", name="Приём заявок")
        obj.set(
            "Контракт входа", ["POST /tasks"], "OBSERVED",
            [Evidence(commit="6a225969b0cc", path="api/routes.py", line=42,
                      basis="эндпоинт POST /tasks")],
        )
        model.add(obj)
        return model

    def test_evidence_explains_instead_of_showing_a_hash(self):
        from pko.render.passports import render_passports

        html = render_passports(self._model())
        self.assertIn("эндпоинт POST /tasks", html)
        self.assertIn("api/routes.py:42", html)
        self.assertNotIn("@6a225969", html,
                         msg="хеш коммита один на версию и печатается в шапке")

    def test_object_note_is_shown_above_the_table(self):
        from pko.render.passports import render_passports

        html = render_passports(
            self._model(),
            notes={"BBB-001": "Блок принимает заявки от клиентов и ставит их в работу."},
            overview="Система принимает заявки и обрабатывает их без участия оператора.",
        )
        self.assertIn("Блок принимает заявки", html)
        self.assertIn("О системе", html)
        self.assertLess(html.index("Блок принимает заявки"), html.index("Контракт входа"),
                        msg="пояснение читают до таблицы полей, а не после")

    def test_gate_card_reference_names_what_was_found(self):
        from pko.extractors.base import Fact
        from pko.gate.evaluate import _refs

        facts = [Fact(kind="GRAPH_NODE", key="plan", value="plan",
                      path="agent/graph.py", line=6, basis="узел графа «plan»")]
        self.assertEqual(_refs(facts), ["agent/graph.py:6 — узел графа «plan»"])

    def test_reference_without_explanation_stays_a_location(self):
        from pko.extractors.base import Fact
        from pko.gate.evaluate import _refs

        self.assertEqual(_refs([Fact(kind="LIMIT", key="t", value=1, path="a.py", line=3)]),
                         ["a.py:3"])
